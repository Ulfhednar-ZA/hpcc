#!/bin/bash

runHpl=$( cat /home/ademellokoch/hpcc/test/HPL_RUN )

echo $runHPL

if [ "$runHpl" -le 1 ] && [ "$HOSTNAME" = "gpu01" ]
then
	echo "IN IF STATEMENT"
	echo $runHpl
	echo $HOSTNAME
	echo 10 > /home/ademellokoch/hpcc/test/HPL_RUN

	source ./bashrc
	./runHPL.job
fi
