#!/bin/bash

if [ $ -eq 0]
then
	source /apps/intel/parallel_studio_xe_2018_update1_cluster_edition/impi/2018.1.163/bin64/mpivars.sh
	export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/data/scratch/cudaHPL
	source /apps/intel/parallel_studio_xe_2018_update1_cluster_edition/mkl/bin/mklvars.sh intel64
	export LD_LIBRARY_PATH=/home/ademellokoch/hpcc/hpcc-1.5.0/cudaHPL:$LD_LIBRARY_PATH

	mpirun ./xhpl
fi
