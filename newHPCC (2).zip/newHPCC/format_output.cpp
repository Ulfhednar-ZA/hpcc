#include <fstream>
#include <string>
#include <sstream>
#include <vector>

/* 
 * ./filereader <filename> <line-number> <word-number>
 * line-number and word-number are 1 indexed.
 * */

using namespace std;

void split(const string &s, char delim, vector<string> &elems) {
    stringstream ss(s);
    string item;
    while (getline(ss, item, delim)) {
        if(item != ""){
             elems.push_back(item);
        }
    }
}

vector<string> split(const string &s, char delim) {
    vector<string> elems;
    split(s, delim, elems);
    return elems;
}

string getNew(char* filename, int line, int word){
    ifstream iFile;
    iFile.open(filename);
    string selectedLine;
    string skipLines;
    for (int i = 0; i < line - 1; i++){
        getline(iFile, skipLines);
    }
    getline(iFile, selectedLine);

    vector<string> wordsInLine = split(selectedLine, ' ');
    string selectedWord = wordsInLine.at(word - 1);

    iFile.close();
    return selectedWord;
}

int main(){
    char* file = "HPL.out";
    string N = getNew(file, 19, 3);
    string NB = getNew(file, 20, 3);
    string P = getNew(file, 22, 3);
    string Q = getNew(file, 23, 3);
    string Pfact = getNew(file, 24, 3);
    string NBmin = getNew(file, 25, 3);
    string Ndiv = getNew(file, 26, 3);
    string Rfact = getNew(file, 27, 3);
    string depth = getNew(file, 29, 3);
    string eps = getNew(file, 41, 11);
    string time = getNew(file, 47, 6);
    string Gflops = getNew(file, 47, 7);
    size_t pos = Gflops.find("e");
    Gflops = Gflops.substr(0, pos);
    
    ifstream filein("hpccoutf.txt");
    ofstream fileout("test.txt");
    string line;
    while(getline(filein, line)){

       if(line == "HPL_Tflops=-1"){
            fileout << ("HPL_Tflops=" + Gflops + "\n");
       }else if(line == "HPL_time=-1"){
            fileout << ("HPL_time=" + time + "\n");
       }else if(line == "HPL_eps=-1"){
            fileout << ("HPL_eps=" + eps + "\n");
       }else if(line == "HPL_N=-1"){
            fileout << ("HPL_N=" + N + "\n");
       }else if(line == "HPL_NB=-1"){
            fileout << ("HPL_NB=" + NB + "\n");
       }else if(line == "HPL_nprow=-1"){
            fileout << ("HPL_nprow=" + P + "\n");
       }else if(line == "HPL_npcol=-1"){
            fileout << ("HPL_npcol=" + Q + "\n");
       }else if(line == "HPL_depth=-1"){
            fileout << ("HPL_depth=" + depth + "\n");
       }else if(line == "HPL_nbdiv=-1"){
            fileout << ("HPL_nbdiv=" + Ndiv + "\n");
       }else if(line == "HPL_nbmin=-1"){
            fileout << ("HPL_nbmin=" + NBmin + "\n");
       }else if(line == "HPL_cpfact=-"){
            fileout << ("HPL_cpfact=" + Pfact + "\n");
       }else if(line == "HPL_crfact=-"){
            fileout << ("HPL_crfact=" + Rfact + "\n");
       }
       else{
            fileout << (line + "\n");
       }

   }

    return 0;
}
