#i/bin/bash

./format_output
mv test.txt hpccoutf.txt
